import warnings
from sklearn.exceptions import ConvergenceWarning
from rdkit import RDLogger
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier, AdaBoostClassifier, ExtraTreesClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, auc
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors
from rdkit.Chem.rdMolDescriptors import GetMorganFingerprintAsBitVect
from rdkit.Chem.rdMolDescriptors import GetHashedMorganFingerprint
#from rdkit.Chem.EState import Fingerprinter as EStateFingerprinter
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV
import joblib
from openbabel import pybel
from skopt.space import Real, Categorical, Integer
import os
from sklearn.metrics import confusion_matrix
from matplotlib.colors import LinearSegmentedColormap

# Suppress various warnings
RDLogger.DisableLog('rdApp.*')
warnings.filterwarnings("ignore")

# Read data
script_dir = os.path.dirname(os.path.abspath(__file__))
dataset_file = os.path.join(script_dir, 'trichomonas_valid.csv')
data = pd.read_csv(dataset_file)

# Define molecular fingerprint function
def calculate_fingerprint(smiles, fp_type):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    if fp_type == 'FP2':
        mol = pybel.readstring('smi', str(smiles))
        fp = mol.calcfp(fp_type)
        bitlist = fp.bits
        rawfp = np.zeros(1025)
        for b in bitlist:
            rawfp[b] = 1
        return list(rawfp)
    elif fp_type == 'FP3':
        mol = pybel.readstring('smi', str(smiles))
        fp = mol.calcfp(fp_type)
        bitlist = fp.bits
        rawfp = np.zeros(56)
        for b in bitlist:
            rawfp[b] = 1
        return list(rawfp)
    elif fp_type == 'FP4':
        mol = pybel.readstring('smi', str(smiles))
        fp = mol.calcfp(fp_type)
        bitlist = fp.bits
        rawfp = np.zeros(308)
        for b in bitlist:
            rawfp[b] = 1
        return list(rawfp)        
    #elif fp_type == 'Estate':
    #    return EStateFingerprinter.FingerprintMol(mol)
    elif fp_type == 'MACCS':
        return AllChem.GetMACCSKeysFingerprint(mol)
    elif fp_type == 'ECFP2':
        return GetMorganFingerprintAsBitVect(mol, 1, nBits=1024)
    elif fp_type == 'ECFP4':
        return GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)
    elif fp_type == 'ECFP6':
        return GetMorganFingerprintAsBitVect(mol, 3, nBits=1024)
    elif fp_type == 'FCFP2':
        return GetMorganFingerprintAsBitVect(mol, 1, nBits=1024, useFeatures=True)
    elif fp_type == 'FCFP4':
        return GetMorganFingerprintAsBitVect(mol, 2, nBits=1024, useFeatures=True)
    elif fp_type == 'FCFP6':
        return GetMorganFingerprintAsBitVect(mol, 3, nBits=1024, useFeatures=True)
    #elif fp_type == 'DLFP':
    #    return AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=2048)
    
# Define algorithms
algorithms = {
    'DT': DecisionTreeClassifier(),
    'KNN': KNeighborsClassifier(n_neighbors = 3),
    'LDA': LinearDiscriminantAnalysis(),
    'GB': GradientBoostingClassifier(),
    'GNB': GaussianNB(),
    'LogR': LogisticRegression(),
    'RF': RandomForestClassifier(random_state=0, n_estimators=50),
    'AB': AdaBoostClassifier(),
    'MLP': MLPClassifier(),
    'XGB': XGBClassifier(),
    'SVM': SVC(probability=True),
    'ET': ExtraTreesClassifier(n_estimators = 10, n_jobs = -1, criterion = 'entropy')
}

# Define used molecular fingerprints
fingerprints = ['FP2', 'FP3', 'FP4', 'MACCS', 'ECFP2', 'ECFP4', 'ECFP6', 'FCFP2', 'FCFP4', 'FCFP6']

# Part 1: Compare performance of different algorithms and molecular fingerprints
results = []

for fp in fingerprints:
    X = np.array([calculate_fingerprint(smiles, fp) for smiles in data['chembl_smiles']])
    y = (data['class'] == 'Active').astype(int)
    #print(y.value_counts())
    
    # Remove invalid molecular fingerprints
    #valid_indices = [i for i, x in enumerate(X) if x is not None]
    #X = np.array([X[i] for i in valid_indices])
    #y = y[valid_indices]
    
    for alg_name, alg in algorithms.items():
        scores = cross_val_score(alg, X, y, cv=5)
        results.append({
            'Algorithm': alg_name,
            'Fingerprint': fp,
            'Accuracy': np.mean(scores),
            'Std': np.std(scores)
        })

results_df = pd.DataFrame(results)
print(results_df.groupby('Fingerprint').size())
print(results_df)

def plot_benchmark_1(results_df, plot_dir, prefix="benchmark_1"):
    fig = plt.figure(figsize=(14, 10), dpi=300)
    gs = fig.add_gridspec(6, 6)

    main_ax = fig.add_subplot(gs[1:, :5])
    pivot_table = results_df.pivot(index='Algorithm', columns='Fingerprint', values='Accuracy')
    heatmap = sns.heatmap(pivot_table, annot=True, cmap='YlGnBu', fmt='.3f', ax=main_ax, cbar=False)
    main_ax.set_title('Benchmark of Various Fingerprints under Algorithms')
    main_ax.set_xlabel('Fingerprints')
    main_ax.set_ylabel('Algorithms')

    top_ax = fig.add_subplot(gs[0, :5])
    sns.boxplot(x='Fingerprint', y='Accuracy', data=results_df, ax=top_ax)
    top_ax.set_xlabel('')
    top_ax.set_xticklabels([])

    right_ax = fig.add_subplot(gs[1:, 5])
    sns.boxplot(y='Algorithm', x='Accuracy', data=results_df, ax=right_ax, orient='h')
    right_ax.set_ylabel('')
    right_ax.set_yticklabels([])

    cbar_ax = fig.add_subplot(gs[0, 5])
    cbar = plt.colorbar(heatmap.get_children()[0], cax=cbar_ax, orientation="horizontal")
    cbar.set_label('Accuracy', labelpad=10)
    cbar_ax.xaxis.set_ticks_position('top')
    cbar_ax.xaxis.set_label_position('top')

    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, f'{prefix}.png'))
    plt.close()

plot_benchmark_1(results_df, script_dir)

# Save results to CSV
results_df.to_csv(os.path.join(script_dir, 'benchmark_results_1.csv'), index=False)

# Part 2: Select the best fingerprint, evaluate performance of different algorithms
best_fp = results_df.groupby('Fingerprint')['Accuracy'].mean().idxmax()
print(best_fp)
X = np.array([calculate_fingerprint(smiles, best_fp) for smiles in data['chembl_smiles']])
y = (data['class'] == 'Active').astype(int)

# Remove invalid molecular fingerprints
#valid_indices = [i for i, x in enumerate(X) if x is not None]
#X = np.array([X[i] for i in valid_indices])
#y = y[valid_indices]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

metrics = ['Sensitivity', 'Specificity', 'Precision', 'F1_score', 'Accuracy', 'AUROC']
results_2 = []

for alg_name, alg in algorithms.items():
    alg.fit(X_train, y_train)
    y_pred = alg.predict(X_test)
    y_pred_proba = alg.predict_proba(X_test)[:, 1]

    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

    results_2.append({
        'Algorithm': alg_name,
        #'Sensitivity': recall_score(y_test, y_pred),
        'Sensitivity': tp / (tp + fn),
        #'Specificity': recall_score(y_test, y_pred, pos_label=0),
        'Specificity': tn / (tn + fp),
        'Precision': precision_score(y_test, y_pred),
        'F1_score': f1_score(y_test, y_pred),
        'Accuracy': accuracy_score(y_test, y_pred),
        'AUROC': roc_auc_score(y_test, y_pred_proba)
    })

results_2_df = pd.DataFrame(results_2)
print(results_2_df)

def plot_benchmark_2(results_df, plot_dir, prefix="benchmark_2"):
    fig = plt.figure(figsize=(16, 12), dpi=300)
    gs = fig.add_gridspec(8, 7, width_ratios=[1, 1, 1, 1, 1, 1, 0.2])

    main_ax = fig.add_subplot(gs[3:, :-1])
    pivot_table = results_df.set_index('Algorithm')
    heatmap = sns.heatmap(pivot_table, annot=True, cmap='YlGnBu', fmt='.3f', ax=main_ax, cbar=False)
    main_ax.set_title('Benchmark of Various Metrics under Algorithms', fontsize=16, pad=20)
    main_ax.set_xlabel('Metrics', fontsize=12)
    main_ax.set_ylabel('Algorithms', fontsize=12)

    top_ax = fig.add_subplot(gs[1:3, :-1])
    melted_df = results_df.melt(id_vars=['Algorithm'], var_name='Metric', value_name='Value')
    sns.boxplot(x='Metric', y='Value', data=melted_df, ax=top_ax, width=0.5)

    top_ax.set_xticks(range(len(metrics)))
    top_ax.set_xticklabels(metrics, rotation=45, ha='right')

    top_ax.set_xlabel('')
    top_ax.set_title('Distribution of Metrics across Algorithms', fontsize=14)

    y_min, y_max = melted_df['Value'].min(), melted_df['Value'].max()
    y_range = y_max - y_min
    top_ax.set_ylim(y_min - 0.1 * y_range, y_max + 0.1 * y_range)

    cbar_ax = fig.add_subplot(gs[3:, -1])
    plt.colorbar(heatmap.collections[0], cax=cbar_ax)
    cbar_ax.set_ylabel('Value', rotation=270, labelpad=20)

    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, f'{prefix}.png'), bbox_inches='tight')
    plt.close()

plot_benchmark_2(results_2_df, script_dir)

# Save results to CSV
results_2_df.to_csv(os.path.join(script_dir, 'benchmark_results_2.csv'), index=False)

# Part 3: Select the best model, perform hyperparameter tuning
best_alg = results_2_df.loc[results_2_df['F1_score'].idxmax(), 'Algorithm']
print(best_alg)
best_model = algorithms[best_alg]

# Hyperparameter tuning
if best_alg == 'RF':
    param_grid = {
        'n_estimators': [1, 10, 100, 200, 300],
        'max_depth': [10, 15,20,30,40,50,60,70,100],
        'max_features': ['sqrt','log2'],
        'random_state': [1],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }
elif best_alg == 'LDA':
    param_grid = {
        'solver': ['svd', 'lsqr', 'eigen'],
        'shrinkage': [None , 'auto' , 0.1 , 0.5 , 0.9], 
        'n_components': [5,7,9,10],
        'tol': [0.0001, 0.00001, 0.001, 0.01] 
    }    
elif best_alg == 'XGB':
    param_grid = {
        'n_estimators': [100, 200, 300, 500, 1000],
        'max_depth': [-1, 3, 5, 7, 10],
        'learning_rate': [0.001, 0.01, 0.1, 0.3],
        'gamma': Real(0, 1, prior='uniform')
    }
elif best_alg == 'AB':
    param_grid = {
        'algorithm': ['SAMME', 'SAMME.R'], 
        'n_estimators': [1,10,100,1000], 
        'random_state': [1]
    }    
elif best_alg == 'ET':
    param_grid = {
        'n_estimators': [1,10,100,1000], 
        'criterion' : ['gini', 'entropy'], 
        'max_depth': [1,3,5,10,15], 
        'max_features': ['sqrt','log2'],
        'min_samples_split': [2,5,10], 
        'random_state': [1]
    }
elif best_alg == 'SVM':
    param_grid = {
        'C' :[0.00001,0.0001,0.001,0.01,0.1,1,10],
        'kernel':['rbf', 'linear'], 
        'random_state': [1],
        'gamma': ['scale', 'auto', 0.1, 1]
    }
elif best_alg == 'KNN':
    param_grid = {
        'n_neighbors': [1,5,10,25,50,100],
        'weights': ['uniform','distance'],
        'algorithm': ['auto','ball_tree','kd_tree']
    }
elif best_alg == 'DT':
    param_grid = {
        'criterion': ['gini', 'entropy'], 
        'max_depth': [1,2,15,20,30,40,50], 
        'max_features': ['sqrt','log2'],
        'min_samples_split': [2,5,10], 
        'random_state': [1]
    }
elif best_alg == 'GB':
    param_grid = {
        'n_estimators': [1, 10, 100, 200, 300, 1000],
        'learning_rate': [0.001, 0.01, 0.1, 0.3, 0.5],
        'subsample' : [0.1,0.5,1.0],
        'max_depth': [1,3,5,10,20,50,100], 
        'random_state': [1]
    }
elif best_alg == 'LogR':
    param_grid = {
        'C': [0.00001,0.0001,0.001,0.01,0.1,1,10],
        'penalty': ['l1', 'l2'],
        'max_iter': [500],
        'solver': ['newton-cg', 'lbfgs', 'liblinear', 'sag', 'saga'],
        'random_state': [1]
    }
elif best_alg == 'MLP':
    param_grid = {
        'hidden_layer_sizes':[(50,), (100,), (50,50), (30,30,30), (25,25,25,25)], 
        'max_iter': [200],
        'activation':['identity', 'logistic', 'tanh', 'relu'], 
        'solver': ['lbfgs', 'sgd', 'adam'], 
        'learning_rate':['constant', 'invscaling', 'adaptive'], 
        'random_state': [1]
    }
else:
    param_grid = {}

if param_grid:
    grid_search = GridSearchCV(best_model, param_grid, cv=10, scoring='f1', n_jobs=-1)
    grid_search.fit(X_train, y_train)
    best_model = grid_search.best_estimator_
    best_params = grid_search.best_params_
else:
    best_model.fit(X_train, y_train)

params_result_df = pd.DataFrame(grid_search.cv_results_)
params_result_df.to_csv(os.path.join(script_dir, 'benchmark_results_3.csv'), index=False)

# Plot ROC curve
y_pred_proba = best_model.predict_proba(X_test)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.savefig(os.path.join(script_dir, 'roc_curve.png'))
plt.close()

# Save model
joblib.dump(best_model, os.path.join(script_dir, 'best_model.joblib'))

# Part 4: Use the best model for prediction
X_all = np.array([calculate_fingerprint(smiles, best_fp) for smiles in data['chembl_smiles']])
y_all = (data['class'] == 'Active').astype(int)

# Remove invalid molecular fingerprints
#valid_indices = [i for i, x in enumerate(X_all) if x is not None]
#X_all = np.array([X_all[i] for i in valid_indices])
#y_all = y_all[valid_indices]
#data_valid = data.iloc[valid_indices]
data_valid = data

y_pred_all = best_model.predict(X_all)

# Calculate molecular weight
def calculate_molecular_weight(smiles):
    mol = Chem.MolFromSmiles(smiles)
    return Descriptors.ExactMolWt(mol) if mol else None

data_valid['molecular_weight'] = data_valid['chembl_smiles'].apply(calculate_molecular_weight)

# Sort data
data_valid['prediction'] = y_pred_all
data_valid['correct'] = (data_valid['prediction'] == y_all).astype(int)
data_valid = data_valid.sort_values(['class', 'molecular_weight'], ascending=[True, False])
data_valid.to_csv(os.path.join(script_dir, 'prediction_results.csv'), index=False)

weight_ranges = pd.cut(data_valid['molecular_weight'], bins=7, ordered=True)

def plot_prediction_distribution(data_valid, weight_ranges, plot_dir):
    if not hasattr(weight_ranges, 'cat'):
        weight_ranges = weight_ranges.astype('category')

    data_valid = data_valid.sort_values('molecular_weight')
    fig = plt.figure(figsize=(16, 6))
    
    gs = fig.add_gridspec(1, 6)
    main_ax = fig.add_subplot(gs[0, :5])
    legend_ax = fig.add_subplot(gs[0, 5])

    for i, (_, row) in enumerate(data_valid.iterrows()):
        color = 'green' if row['correct'] else 'red'
        y = 0 if row['class'] == 'Active' else -0.5
        main_ax.plot([i, i], [y, y+0.5], color=color, linewidth=0.5, alpha=0.7)

    colors = plt.cm.rainbow(np.linspace(0, 1, len(weight_ranges.cat.categories)))
    start = 0
    for i, (range_name, group) in enumerate(data_valid.groupby(weight_ranges)):
        if not group.empty:
            end = start + len(group)
            main_ax.axhspan(-0.7, -0.6, xmin=start/len(data_valid), xmax=end/len(data_valid), 
                       facecolor=colors[i], alpha=0.7)
            start = end

    main_ax.set_xlim(0, len(data_valid))
    main_ax.set_ylim(-0.7, 0.5)
    main_ax.set_yticks([-0.25, 0.25])
    main_ax.set_yticklabels(['Inactive', 'Active'])
    main_ax.set_xticks([])
    main_ax.set_xlabel('Compounds', fontsize=12)
    main_ax.set_title('Prediction Results Distribution', fontsize=16)

    legend_ax.axis('off')
    
    legend_handles = [plt.Line2D([0], [0], color='green', label='Correct Prediction'),
                      plt.Line2D([0], [0], color='red', label='Incorrect Prediction')]
    
    weight_range_labels = [f"{r.left:.0f}-{r.right:.0f}" for r in weight_ranges.cat.categories]
    legend_handles += [plt.Rectangle((0,0),1,1, facecolor=colors[i], alpha=0.7, label=label) 
                       for i, label in enumerate(weight_range_labels)]
    
    legend_ax.legend(handles=legend_handles, loc='center left', 
                     #title="Legend", 
                     bbox_to_anchor=(0, 0.5), fontsize='small')

    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, 'prediction_distribution.png'), dpi=300, bbox_inches='tight')
    plt.close()

plot_prediction_distribution(data_valid, weight_ranges, script_dir)

# Statistics for different molecular weight ranges
weight_stats = data_valid.groupby(weight_ranges).agg({
    'compound_chembl_id': 'count',
    'class': lambda x: (x == 'Active').sum(),
    'prediction': 'sum',
    'correct': 'sum'
}).reset_index()

weight_stats.columns = ['Weight_Range', 'Total', 'Actual_Active', 'Predicted_Active', 'Correct_Predictions']
weight_stats['Actual_Inactive'] = weight_stats['Total'] - weight_stats['Actual_Active']
weight_stats['Predicted_Inactive'] = weight_stats['Total'] - weight_stats['Predicted_Active']
weight_stats['Incorrect_Predictions'] = weight_stats['Total'] - weight_stats['Correct_Predictions']
weight_stats['Accuracy'] = weight_stats['Correct_Predictions'] / weight_stats['Total']
weight_stats['Error_Rate'] = 1 - weight_stats['Accuracy']

# Save statistics results
weight_stats.to_csv(os.path.join(script_dir, 'prediction_stats.csv'), index=False)

print("All tasks completed. Please check the output files in the current directory.")