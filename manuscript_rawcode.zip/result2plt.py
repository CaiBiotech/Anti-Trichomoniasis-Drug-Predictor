from matplotlib.colors import LinearSegmentedColormap
import warnings
from sklearn.exceptions import ConvergenceWarning
from rdkit import RDLogger
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier, AdaBoostClassifier, ExtraTreesClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, auc
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors
from rdkit.Chem.rdMolDescriptors import GetMorganFingerprintAsBitVect
from rdkit.Chem.rdMolDescriptors import GetHashedMorganFingerprint
#from rdkit.Chem.EState import Fingerprinter as EStateFingerprinter
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV
import joblib
from openbabel import pybel
from skopt.space import Real, Categorical, Integer
import os
from sklearn.metrics import confusion_matrix

# Suppress various warnings
RDLogger.DisableLog('rdApp.*')
warnings.filterwarnings("ignore")

def plot_benchmark_1(results_df, plot_dir, prefix="benchmark_1"):
    fig = plt.figure(figsize=(14, 10), dpi=300)

    # Create grid
    gs = fig.add_gridspec(6, 6)

    # Main heatmap
    main_ax = fig.add_subplot(gs[1:, :5])
    pivot_table = results_df.pivot(index='Algorithm', columns='Fingerprint', values='Accuracy')
    heatmap = sns.heatmap(pivot_table, annot=True, cmap='YlOrRd', fmt='.3f', ax=main_ax, cbar=False)
    main_ax.set_title('Benchmark of Various Fingerprints under Algorithms')
    main_ax.set_xlabel('Fingerprints')
    main_ax.set_ylabel('Algorithms')

    # Top boxplot (evaluation metrics)
    top_ax = fig.add_subplot(gs[0, :5])
    sns.boxplot(x='Fingerprint', y='Accuracy', data=results_df, ax=top_ax)
    top_ax.set_xlabel('')
    top_ax.set_xticklabels([])

    # Right boxplot (algorithms)
    right_ax = fig.add_subplot(gs[1:, 5])
    sns.boxplot(y='Algorithm', x='Accuracy', data=results_df, ax=right_ax, orient='h')
    right_ax.set_ylabel('')
    right_ax.set_yticklabels([])

    # Color bar
    cbar_ax = fig.add_subplot(gs[0, 5])
    cbar = plt.colorbar(heatmap.get_children()[0], cax=cbar_ax, orientation="horizontal")
    cbar.set_label('Accuracy', labelpad=10)
    cbar_ax.xaxis.set_ticks_position('top')
    cbar_ax.xaxis.set_label_position('top')

    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, f'{prefix}.png'))
    plt.close()

def plot_benchmark_2(results_df, plot_dir, prefix="benchmark_2"):
    fig = plt.figure(figsize=(16, 12), dpi=300)
    metrics = ['Sensitivity', 'Specificity', 'Precision', 'F1_score', 'Accuracy', 'AUROC']

    # Create grid
    gs = fig.add_gridspec(8, 7, width_ratios=[1, 1, 1, 1, 1, 1, 0.2])

    # Main heatmap
    main_ax = fig.add_subplot(gs[3:, :-1])
    pivot_table = results_df.set_index('Algorithm')
    heatmap = sns.heatmap(pivot_table, annot=True, cmap='YlOrRd', fmt='.3f', ax=main_ax, cbar=False)
    main_ax.set_title('Benchmark of Various Metrics under Algorithms', fontsize=16, pad=20)
    main_ax.set_xlabel('Metrics', fontsize=12)
    main_ax.set_ylabel('Algorithms', fontsize=12)

    # Top boxplot (evaluation metrics)
    top_ax = fig.add_subplot(gs[1:3, :-1])
    melted_df = results_df.melt(id_vars=['Algorithm'], var_name='Metric', value_name='Value')
    sns.boxplot(x='Metric', y='Value', data=melted_df, ax=top_ax, width=0.5)

    top_ax.set_xticks(range(len(metrics)))
    top_ax.set_xticklabels(metrics, rotation=45, ha='right')

    top_ax.set_xlabel('')
    top_ax.set_title('Distribution of Metrics across Algorithms', fontsize=14)

    # Adjust y-axis range of boxplot
    y_min, y_max = melted_df['Value'].min(), melted_df['Value'].max()
    y_range = y_max - y_min
    top_ax.set_ylim(y_min - 0.1 * y_range, y_max + 0.1 * y_range)

    # Color bar
    cbar_ax = fig.add_subplot(gs[3:, -1])
    plt.colorbar(heatmap.collections[0], cax=cbar_ax)
    cbar_ax.set_ylabel('Value', rotation=270, labelpad=20)

    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, f'{prefix}.png'), bbox_inches='tight')
    plt.close()

def plot_prediction_distribution(data_valid, weight_ranges, plot_dir):
    if not hasattr(weight_ranges, 'cat'):
        weight_ranges = weight_ranges.astype('category')

    # Sort by molecular weight
    data_valid = data_valid.sort_values('molecular_weight')

    # Create figure
    fig = plt.figure(figsize=(16, 4))
    
    # Create subplots for main plot and legend
    gs = fig.add_gridspec(1, 6)
    main_ax = fig.add_subplot(gs[0, :5])
    legend_ax = fig.add_subplot(gs[0, 5])

    # Plot prediction results
    for i, (_, row) in enumerate(data_valid.iterrows()):
        color = 'green' if row['correct'] else 'red'
        y = 0 if row['class'] == 'Active' else -0.5
        main_ax.plot([i, i], [y, y+0.5], color=color, linewidth=0.5, alpha=0.7)

    # Add background color for molecular weight ranges
    colors = plt.cm.rainbow(np.linspace(0, 1, len(weight_ranges.cat.categories)))
    start = 0
    for i, (range_name, group) in enumerate(data_valid.groupby(weight_ranges)):
        if not group.empty:
            end = start + len(group)
            main_ax.axhspan(-0.7, -0.6, xmin=start/len(data_valid), xmax=end/len(data_valid), 
                       facecolor=colors[i], alpha=0.7)
            start = end

    # Set main plot axes
    main_ax.set_xlim(0, len(data_valid))
    main_ax.set_ylim(-0.7, 0.5)
    main_ax.set_yticks([-0.25, 0.25])
    main_ax.set_yticklabels(['Inactive', 'Active'])
    main_ax.set_xticks([])
    main_ax.set_xlabel('Compounds', fontsize=12)
    main_ax.set_title('Prediction Results Distribution', fontsize=16)

    # Add all legends in the legend subplot
    legend_ax.axis('off')
    
    # Prediction result legend
    legend_handles = [plt.Line2D([0], [0], color='green', label='Correct Prediction'),
                      plt.Line2D([0], [0], color='red', label='Incorrect Prediction')]
    
    # Molecular weight range legend
    weight_range_labels = [f"{r.left:.0f}-{r.right:.0f}" for r in weight_ranges.cat.categories]
    legend_handles += [plt.Rectangle((0,0),1,1, facecolor=colors[i], alpha=0.7, label=label) 
                       for i, label in enumerate(weight_range_labels)]
    
    # Create combined legend
    legend_ax.legend(handles=legend_handles, loc='center left', 
                     bbox_to_anchor=(0, 0.5), fontsize='small')

    plt.tight_layout()
    plt.savefig(os.path.join(plot_dir, 'prediction_distribution.png'), dpi=300, bbox_inches='tight')
    plt.close()

script_dir = os.path.dirname(os.path.abspath(__file__))
results_df_file = os.path.join(script_dir, 'benchmark_results_1.csv')
results_df = pd.read_csv(results_df_file)
plot_benchmark_1(results_df, script_dir)

results_2_df_file = os.path.join(script_dir, 'benchmark_results_2.csv')
results_2_df = pd.read_csv(results_2_df_file)
plot_benchmark_2(results_2_df, script_dir)

data_valid_file = os.path.join(script_dir, 'prediction_results.csv')
data_valid = pd.read_csv(data_valid_file)
weight_ranges = pd.cut(data_valid['molecular_weight'], bins=7, ordered=True)
plot_prediction_distribution(data_valid, weight_ranges, script_dir)