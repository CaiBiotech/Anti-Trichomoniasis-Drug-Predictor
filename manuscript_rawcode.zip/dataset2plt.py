import matplotlib
matplotlib.use('Agg')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit import DataStructs
from rdkit.Chem import AllChem
from rdkit.Chem import Descriptors
from rdkit.Chem.rdFingerprintGenerator import GetMorganGenerator
from sklearn.decomposition import PCA
from collections import Counter
import os
import requests

# 读取数据
script_dir = os.path.dirname(os.path.abspath(__file__))
dataset_file = os.path.join(script_dir, 'trichomonas_valid.csv')
df = pd.read_csv(dataset_file)

# 1. 化学相似性分析
def calculate_similarity(smiles1, smiles2):
    mol1 = Chem.MolFromSmiles(smiles1)
    mol2 = Chem.MolFromSmiles(smiles2)
    
    gen = GetMorganGenerator(includeChirality=True, radius=2, fpSize=1024)
    fp1 = gen.GetFingerprint(mol1)
    fp2 = gen.GetFingerprint(mol2)
    
    return DataStructs.TanimotoSimilarity(fp1, fp2)

similarities = []
for i in range(len(df)):
    for j in range(i+1, len(df)):
        sim = calculate_similarity(df['chembl_smiles'].iloc[i], df['chembl_smiles'].iloc[j])
        similarities.append(sim)

plt.figure(figsize=(10, 6))
plt.hist(similarities, bins=50)
plt.title('Chemical Similarity Distribution')
plt.xlabel('Tanimoto Similarity')
plt.ylabel('Frequency')
plt.savefig(os.path.join(script_dir, 'similarity_histogram.png'))
plt.close()

# 2. 化合物类型分类
def classify_compound1(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return "Other"
    
    # Define SMARTS patterns
    patterns = {
        "Phenylpropanoids": "c1ccc(cc1)CC=C",
        "Flavonoids": "c1cc(c2c(c1)OC(CC2=O)c3ccccc3)O",
        "Tannins": "c1cc(c(c(c1O)O)O)C(=O)O",
        "Alkaloids": "[NX3;H2,H1;!$(NC=O)]",
        "Terpenoids": "C(C)(C)C1CCC2(C1(CCC3C2CCC4C3(CCC(C4)O)C)C)C",
        "Glycosides": "C1OC(C(C(C1O)O)O)CO",
        "Quinones": "O=C1C=CC(=O)C=C1",
        "Steroids": "C1CCC2(C(C1)CCC3C2CC=C4C3(CCC(C4)O)C)C",
        "Isoprenoids": "CC(=C)CCC=C(C)C",
        "Fatty acids": "CCCCCCCCCC(=O)O",
        "Polyketides": "CC(=O)CC(C(=O)C)O",
        "Carbohydrates": "OCC1OC(O)C(O)C(O)C1O"
    }

    colours = {        
        "Phenylpropanoids": "#A783B6",  # purple
        "Flavonoids": "#9BC2BA",  # soft bluegreen
        "Tannins": "#BBBBBB",
        "Alkaloids": "#B4CAD8",  # purple
        "Terpenoids": "#B9C311",  # green
        "Glycosides": "#797979",
        "Quinones": "#FFEAA0",
        "Steroids": "#FFC4CE",
        "Isoprenoids": "#393939",  # green
        "Fatty acids": "#FF8B61",  # orange
        "Carbohydrates": "#FFC4CE",  # pink
        "Polyketides": "#C21100",  # soft red
        #"Amino acids and Peptides": "#FFEAA0",  # yellow
        "Other": "#595959",
        #"synthetic": "#393939",  # grey
    }

    # Check for pattern matches
    for compound_type, smarts in patterns.items():
        pattern = Chem.MolFromSmarts(smarts)
        if mol.HasSubstructMatch(pattern):
            return compound_type
    
    # If no specific pattern matched, try to classify based on simple rules
    return "Other"

def classify_compound2(smiles):
    url = "https://npclassifier.ucsd.edu/classify"
    response = requests.get(url, params={"smiles": smiles})
    if response.status_code == 200:
        data = response.json()
        data["smiles"] = smiles
        if data["pathway_results"] and data["pathway_results"][0]:
            superclass = data["pathway_results"][0]
            if superclass == "Shikimates and Phenylpropanoids":
                superclass = "Phenylpropanoids"
            elif superclass == "Amino acids and Peptides":
                superclass = "Peptides"
            data["superclass"] = superclass
            print(data["superclass"])
            return data["superclass"]
    return "Other"

# 应用函数到数据框
df['compound_type'] = df['chembl_smiles'].apply(classify_compound2)

# 计算每种类型的数量
type_counts = df['compound_type'].value_counts()
total = sum(type_counts.values)

# 绘制柱状图
plt.figure(figsize=(12, 8))
y_pos = range(len(type_counts))

plt.barh(y_pos, type_counts.values)
plt.yticks(y_pos, type_counts.index)
plt.xlabel('Count')
plt.ylabel('Compound Type')
plt.title('Distribution of Compound Database Class')

# 添加数值标注
for i, count in enumerate(type_counts.values):
    percentage = count / total * 100
    plt.text(count + 0.1, i, f'{count} ({percentage:.1f}%)', va='center')

plt.title('Distribution of Compound Database Class')
plt.savefig(os.path.join(script_dir, 'compound_types_pie.png'), bbox_inches='tight')
plt.close()

# 3. PCA分析
def smiles_to_fp(smiles):
    mol = Chem.MolFromSmiles(smiles)
    gen = GetMorganGenerator(includeChirality=True, radius=2, fpSize=1024)
    return gen.GetFingerprint(mol)

X = np.array([smiles_to_fp(s) for s in df['chembl_smiles']])
y = df['class'].map({'Active': 1, 'Inactive': 0})

pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

plt.figure(figsize=(10, 8))
#scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='viridis')
#plt.colorbar(scatter)

# 设置active和inactive化合物的颜色
colors = ['#1f77b4', '#ff7f0e']  # 蓝色表示active,橙色表示inactive
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=[colors[i] for i in y])

# 添加图例
plt.legend(handles=[plt.Line2D([0], [0], marker='o', color='w', label=l, 
                               markerfacecolor=c, markersize=8) 
                    for l, c in zip(['Active', 'Inactive'], colors)], 
           loc='lower right')

plt.title('PCA of Active and Inactive Compounds')
plt.xlabel('First Principal Component')
plt.ylabel('Second Principal Component')
plt.savefig(os.path.join(script_dir, 'pca_dataset.png'))
plt.close()

# 保存结果到CSV
results = pd.DataFrame({
    'compound_chembl_id': df['compound_chembl_id'],
    'chembl_smiles': df['chembl_smiles'],
    'pchembl_value': df['pchembl_value'],
    'class': df['class'],
    'compound_type': df['compound_type'],
    'pca_component1': X_pca[:, 0],
    'pca_component2': X_pca[:, 1]
})
results.to_csv(os.path.join(script_dir, 'dataset_results.csv'), index=False)

print("分析完成，结果已保存到 dataset_results.csv")